#!/usr/bin/env python3

import requests
import whois
import subprocess
import socket
import threading
import os
import time
from datetime import datetime
from colorama import Fore, Style, init

init(autoreset=True)


class ReconEagle:

    def __init__(self):
        self.target = ""
        self.results = {
            "whois": {},
            "dns": {},
            "subdomains": [],
            "ports": [],
            "banners": {},
            "technologies": []
        }

    # ---------------- BANNER ----------------
    def banner(self):
        print(Fore.YELLOW + r"""
██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗
██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║
██████╔╝█████╗  ██║     ██║   ██║██╔██╗ ██║
██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╗██║
██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚████║
╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝
        🦅  R E C O N   E A G L E  🦅
   Lightweight Custom Reconnaissance Tool
------------------------------------------------
""")

    # ---------------- TARGET INPUT ----------------
    def get_target(self):
        self.target = input(Fore.GREEN + "Enter target domain (example: google.com): ").strip()
        self.target = self.target.replace("http://", "").replace("https://", "").split("/")[0]

    # ---------------- HELPER ----------------
    def clean(self, value):
        if isinstance(value, list):
            return str(value[0])
        if hasattr(value, "strftime"):
            return value.strftime("%Y-%m-%d")
        return str(value)

    # ---------------- WHOIS ----------------
    def whois_lookup(self):
        print("[+] Performing WHOIS lookup...")
        try:
            w = whois.whois(self.target)
            self.results["whois"] = {
                "Domain": self.clean(w.domain_name),
                "Registrar": self.clean(w.registrar),
                "Created": self.clean(w.creation_date),
                "Expires": self.clean(w.expiration_date),
                "Status": self.clean(w.status)
            }
        except:
            self.results["whois"] = {"Error": "WHOIS lookup failed"}

    # ---------------- DNS ----------------
    def dns_enum(self):
        print("[+] Performing DNS enumeration...")
        dns_data = {"A": [], "MX": [], "NS": []}

        try:
            dns_data["A"] = subprocess.run(
                ["dig", "+short", self.target],
                capture_output=True, text=True
            ).stdout.splitlines()
        except:
            pass

        try:
            dns_data["MX"] = subprocess.run(
                ["dig", "+short", "MX", self.target],
                capture_output=True, text=True
            ).stdout.splitlines()
        except:
            pass

        try:
            dns_data["NS"] = subprocess.run(
                ["dig", "+short", "NS", self.target],
                capture_output=True, text=True
            ).stdout.splitlines()
        except:
            pass

        self.results["dns"] = dns_data

    # ---------------- SUBDOMAINS (crt.sh) ----------------
    def subdomain_enum(self):
        print("[+] Performing subdomain enumeration (crt.sh)...")
        subs = set()
        try:
            url = f"https://crt.sh/?q=%.{self.target}&output=json"
            r = requests.get(url, timeout=10)
            if r.status_code == 200:
                for entry in r.json():
                    name = entry.get("name_value", "")
                    for sub in name.split("\n"):
                        if self.target in sub:
                            subs.add(sub.strip())
        except:
            pass

        self.results["subdomains"] = list(subs)[:20]

    # ---------------- PORT SCAN ----------------
    def port_scan(self):
        print("[+] Performing port scan...")
        ports = [21, 22, 80, 443, 8080]
        open_ports = []

        def scan(p):
            try:
                s = socket.socket()
                s.settimeout(1)
                if s.connect_ex((self.target, p)) == 0:
                    open_ports.append(p)
                s.close()
            except:
                pass

        threads = []
        for p in ports:
            t = threading.Thread(target=scan, args=(p,))
            t.start()
            threads.append(t)

        for t in threads:
            t.join()

        self.results["ports"] = sorted(open_ports)

    # ---------------- BANNER GRAB ----------------
    def banner_grab(self):
        print("[+] Performing banner grabbing...")
        for port in self.results["ports"]:
            try:
                s = socket.socket()
                s.settimeout(2)
                s.connect((self.target, port))
                s.send(b"HEAD / HTTP/1.0\r\n\r\n")
                banner = s.recv(1024).decode(errors="ignore").split("\n")[0]
                self.results["banners"][port] = banner
                s.close()
            except:
                pass

    # ---------------- TECH DETECTION ----------------
    def tech_detect(self):
        print("[+] Detecting technologies...")
        try:
            r = subprocess.run(
                ["whatweb", "-q", self.target],
                capture_output=True, text=True
            )
            self.results["technologies"] = r.stdout.strip().split(", ")
        except:
            pass

    # ---------------- REPORT ----------------
    def generate_txt_report(self):
        filename = f"recon_report_{self.target}_{int(time.time())}.txt"
        with open(filename, "w") as f:
            f.write("RECON EAGLE REPORT\n")
            f.write("=" * 50 + "\n")
            f.write(f"Target    : {self.target}\n")
            f.write(f"Timestamp : {datetime.now()}\n\n")

            f.write("=== WHOIS INFORMATION ===\n")
            for k, v in self.results["whois"].items():
                f.write(f"{k:12}: {v}\n")

            f.write("\n=== DNS INFORMATION ===\n")
            for r, vals in self.results["dns"].items():
                f.write(f"\n{r} Records:\n")
                for v in vals:
                    f.write(f"  - {v}\n")

            f.write("\n=== SUBDOMAINS ===\n")
            for s in self.results["subdomains"]:
                f.write(f"  - {s}\n")

            f.write("\n=== OPEN PORTS ===\n")
            for p in self.results["ports"]:
                f.write(f"  - Port {p}\n")

            f.write("\n=== BANNERS ===\n")
            for p, b in self.results["banners"].items():
                f.write(f"Port {p}: {b}\n")

            f.write("\n=== TECHNOLOGIES ===\n")
            for t in self.results["technologies"]:
                f.write(f"  - {t}\n")

            f.write("\nReport Generated by Recon Eagle\n")

        print(Fore.GREEN + f"\n[✔] TXT Report saved: {filename}")

    # ---------------- RUN ----------------
    def run(self):
        self.banner()
        self.get_target()
        self.whois_lookup()
        self.dns_enum()
        self.subdomain_enum()
        self.port_scan()
        self.banner_grab()
        self.tech_detect()
        self.generate_txt_report()


if __name__ == "__main__":
    ReconEagle().run()
